int  main()
{
  long long y
